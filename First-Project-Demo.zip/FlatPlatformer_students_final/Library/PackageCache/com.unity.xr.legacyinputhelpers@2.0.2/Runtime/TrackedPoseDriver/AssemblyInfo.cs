using System.Runtime.CompilerServices;
using UnityEngine;

// ADD_NEW_PLATFORM_HERE
[assembly: InternalsVisibleTo("UnityEditor.XR.SpatialTracking")]
