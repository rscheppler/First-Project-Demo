﻿/* By: Bulat Sultanov
 * Date: 2017
 * Description: Rotates windmill over the update function
 */

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WindMill : MonoBehaviour {
    public float _Speed;
    private float _currDist, _dist;


}
